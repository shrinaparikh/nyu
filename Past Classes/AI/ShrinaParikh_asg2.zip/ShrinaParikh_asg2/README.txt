#Shrina Parikh

run frontend.py with input in file "frontend_input.txt"
then run davis_putnam.py
then run backend.py

the final output will be in backend.txt

I have included the files and result I got with the sample provided as well as an empty frontend_input.txt file